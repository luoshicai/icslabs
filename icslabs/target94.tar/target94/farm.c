/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_407(unsigned *p)
{
    *p = 2425394264U;
}

unsigned addval_472(unsigned x)
{
    return x + 2445773128U;
}

void setval_437(unsigned *p)
{
    *p = 2425393240U;
}

unsigned getval_309()
{
    return 3281031256U;
}

unsigned addval_473(unsigned x)
{
    return x + 3344487017U;
}

void setval_254(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_471()
{
    return 3284633928U;
}

unsigned addval_195(unsigned x)
{
    return x + 2429012296U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_343(unsigned x)
{
    return x + 3380924825U;
}

unsigned addval_103(unsigned x)
{
    return x + 3525890441U;
}

unsigned addval_194(unsigned x)
{
    return x + 3252717896U;
}

void setval_261(unsigned *p)
{
    *p = 3281047241U;
}

unsigned addval_282(unsigned x)
{
    return x + 3281047949U;
}

unsigned getval_205()
{
    return 3523789321U;
}

void setval_456(unsigned *p)
{
    *p = 3531919753U;
}

unsigned addval_348(unsigned x)
{
    return x + 3223899785U;
}

void setval_202(unsigned *p)
{
    *p = 3374370433U;
}

unsigned addval_238(unsigned x)
{
    return x + 3523789449U;
}

unsigned getval_458()
{
    return 3674784265U;
}

void setval_305(unsigned *p)
{
    *p = 3247492745U;
}

unsigned getval_271()
{
    return 3250751982U;
}

void setval_280(unsigned *p)
{
    *p = 2497743176U;
}

unsigned addval_375(unsigned x)
{
    return x + 3222851209U;
}

unsigned addval_355(unsigned x)
{
    return x + 2428668358U;
}

unsigned getval_359()
{
    return 3531915905U;
}

unsigned addval_477(unsigned x)
{
    return x + 1472447105U;
}

void setval_134(unsigned *p)
{
    *p = 3380924041U;
}

unsigned addval_448(unsigned x)
{
    return x + 2447411528U;
}

void setval_410(unsigned *p)
{
    *p = 3682913961U;
}

unsigned addval_227(unsigned x)
{
    return x + 3281047177U;
}

unsigned getval_404()
{
    return 3348156809U;
}

void setval_460(unsigned *p)
{
    *p = 3526935169U;
}

unsigned getval_315()
{
    return 2425409993U;
}

unsigned getval_463()
{
    return 3682914697U;
}

unsigned getval_427()
{
    return 2430634248U;
}

unsigned addval_397(unsigned x)
{
    return x + 2425672073U;
}

unsigned getval_257()
{
    return 3286272328U;
}

unsigned addval_162(unsigned x)
{
    return x + 3767091328U;
}

unsigned getval_385()
{
    return 3269495112U;
}

unsigned getval_415()
{
    return 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
